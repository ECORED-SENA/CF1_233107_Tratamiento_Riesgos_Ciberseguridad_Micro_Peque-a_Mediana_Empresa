function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5gKoWBx9vGQ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

