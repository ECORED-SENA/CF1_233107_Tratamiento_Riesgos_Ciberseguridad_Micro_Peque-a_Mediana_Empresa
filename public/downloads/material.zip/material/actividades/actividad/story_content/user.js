function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6KY0ta6h7yq":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

